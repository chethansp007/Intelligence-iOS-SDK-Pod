//
//  IntelligenceSDK.h
//  IntelligenceSDK
//
//  Created by Małgorzata Dybizbańska on 20/07/15.
//  Copyright © 2015 Tigerspike. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for IntelligenceSDK.
FOUNDATION_EXPORT double IntelligenceSDKVersionNumber;

//! Project version string for IntelligenceSDK.
FOUNDATION_EXPORT const unsigned char IntelligenceSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <IntelligenceSDK/PublicHeader.h>


